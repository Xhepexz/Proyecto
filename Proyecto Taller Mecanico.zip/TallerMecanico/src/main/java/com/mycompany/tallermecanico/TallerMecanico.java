/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallermecanico;

import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author juman
 */
public class TallerMecanico {

    public static void main(String[] args) {
        ServicioTaller servicioTaller = new ServicioTaller();
        Factura factura = new Factura();

        int opcion;
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("Menú Principal\n1. Ingresar nuevo carro\n2. Ingresar servicios\n3. Generar factura\n4. Salir"));
            switch (opcion) {
                case 1:
                    ingresarCarro(servicioTaller);
                    break;
                case 2:
                    ingresarServicios(servicioTaller);
                    break;
                case 3:
                    generarFactura(servicioTaller, factura);
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saliendo del programa", "Salir", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (opcion != 4);
    }

    private static void ingresarCarro(ServicioTaller servicioTaller) {
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo del carro:");
        String placa = JOptionPane.showInputDialog("Ingrese la placa del carro:");
        boolean marchamoAlDia = Boolean.parseBoolean(JOptionPane.showInputDialog("¿Tiene el marchamo al día? (true/false):"));
        boolean rtvAlDia = Boolean.parseBoolean(JOptionPane.showInputDialog("¿Tiene el RTV al día? (true/false):"));
        boolean tieneGolpes = Boolean.parseBoolean(JOptionPane.showInputDialog("¿Tiene golpes? (true/false):"));
        String notasAdicionales = JOptionPane.showInputDialog("Ingrese notas adicionales:");

        Carro carro = new Carro(modelo, placa, marchamoAlDia, rtvAlDia, tieneGolpes, notasAdicionales);
        Gestor.guardarCarro(carro);
    }

    private static void ingresarServicios(ServicioTaller servicioTaller) {
        StringBuilder sb = new StringBuilder("Servicios Disponibles:\n");
        List<Servicio> serviciosDisponibles = (List<Servicio>) servicioTaller.getServiciosDisponibles();
        for (int i = 0; i < serviciosDisponibles.size(); i++) {
            sb.append((i + 1)).append(". ").append(serviciosDisponibles.get(i).getNombre()).append(" - $").append(serviciosDisponibles.get(i).getPrecio()).append("\n");
        }
        int seleccion = Integer.parseInt(JOptionPane.showInputDialog(sb.toString() + "Seleccione el número del servicio que desea aplicar:")) - 1;

    }

    private static void generarFactura(ServicioTaller servicioTaller, Factura factura) {
}
}