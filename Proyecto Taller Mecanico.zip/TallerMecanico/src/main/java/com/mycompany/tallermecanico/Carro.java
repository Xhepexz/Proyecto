/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallermecanico;

/**
 *
 * @author juman
 */
public class Carro {
    
    private String modelo;
    private String placa;
    private boolean marchamoAlDia;
    private boolean rtvAlDia;
    private boolean tieneGolpes;
    private String notasAdicionales;

    public Carro(String modelo, String placa, boolean marchamoAlDia, boolean rtvAlDia, boolean tieneGolpes, String notasAdicionales) {
        this.modelo = modelo;
        this.placa = placa;
        this.marchamoAlDia = marchamoAlDia;
        this.rtvAlDia = rtvAlDia;
        this.tieneGolpes = tieneGolpes;
        this.notasAdicionales = notasAdicionales;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public boolean isMarchamoAlDia() {
        return marchamoAlDia;
    }

    public boolean isRtvAlDia() {
        return rtvAlDia;
    }

    public boolean isTieneGolpes() {
        return tieneGolpes;
    }

    public String getNotasAdicionales() {
        return notasAdicionales;
    }
}