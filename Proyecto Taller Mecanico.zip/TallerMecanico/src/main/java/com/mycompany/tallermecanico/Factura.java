/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallermecanico;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author juman
 */
public class Factura {
    
    private List<Factura> facturas;

    public Factura() {
        facturas = new ArrayList<>();
    }

    private Factura(Carro carro, List<Servicio> serviciosAplicados, String fecha) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void generarFactura(Carro carro, List<Servicio> serviciosAplicados, String fecha) {
        Factura factura = new Factura(carro, serviciosAplicados, fecha);
        facturas.add(factura);
    }

    public List<Factura> getFacturas() {
        return facturas;
    }
}