/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallermecanico;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author juman
 */
public class ServicioTaller {
    
    private List<Servicio> serviciosDisponibles;

    public ServicioTaller() {
        serviciosDisponibles = new ArrayList<>();
        serviciosDisponibles.add(new Servicio("Cambio de aceite", 15000.0));
        serviciosDisponibles.add(new Servicio("Cambio de liquido de frenos", 20000.0));
        serviciosDisponibles.add(new Servicio("Cambio de liquido de direccion hidraulica", 10000.0));
        serviciosDisponibles.add(new Servicio("Cambio de coolant", 10000.0));
        serviciosDisponibles.add(new Servicio("Cambio de fibras de freno", 20000.0));
        serviciosDisponibles.add(new Servicio("Cambio de compensadores", 40000.0));
                
    }

    public void agregarServicio(Servicio servicio) {
        serviciosDisponibles.add(servicio);
    }

    public List<Servicio> getServiciosDisponibles() {
        return serviciosDisponibles;
    }
}