/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tallermecanico;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author juman
 */
public class Gestor {
    
    private static final String DIRECTORIO = "carros/";

    public static void guardarCarro(Carro carro) {
        String nombreArchivo = DIRECTORIO + carro.getPlaca() + ".txt";
        
        File directorio = new File(DIRECTORIO);
        if (!directorio.exists()) {
            if (!directorio.mkdirs()) {
                JOptionPane.showMessageDialog(null, "Error al crear el directorio para guardar el carro", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            writer.write("Modelo: " + carro.getModelo());
            writer.newLine();
            writer.write("Placa: " + carro.getPlaca());
            writer.newLine();
            writer.write("Marchamo al día: " + carro.isMarchamoAlDia());
            writer.newLine();
            writer.write("RTV al día: " + carro.isRtvAlDia());
            writer.newLine();
            writer.write("Tiene golpes: " + carro.isTieneGolpes());
            writer.newLine();
            writer.write("Notas adicionales: " + carro.getNotasAdicionales());
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el carro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
